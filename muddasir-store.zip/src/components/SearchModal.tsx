import React, { useState, useEffect, useRef } from 'react';
import { useShop } from '../context/ShopContext';
import { PRODUCTS } from '../data/products';
import { Search, X, Star, ArrowRight, ShoppingBag } from 'lucide-react';

export const SearchModal: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    setDetailProduct,
    addToCart,
    setSelectedCategory,
    setActivePage
  } = useShop();

  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const results = query.trim() === ''
    ? PRODUCTS.slice(0, 4)
    : PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.category.toLowerCase().includes(query.toLowerCase()) ||
        p.shortDescription.toLowerCase().includes(query.toLowerCase())
      );

  const quickTags = ['Audio', 'Chargers', 'Earbuds', 'Speakers', 'Accessories', 'Power'];

  const handleTagClick = (tag: string) => {
    setIsSearchOpen(false);
    setSelectedCategory(tag);
    setActivePage('shop');
  };

  const handleProductSelect = (prod: typeof PRODUCTS[0]) => {
    setIsSearchOpen(false);
    setDetailProduct(prod);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-md transition-opacity"
        onClick={() => setIsSearchOpen(false)}
      />

      {/* Dialog Box */}
      <div className="relative bg-[#071126] text-white rounded-3xl max-w-2xl w-full border border-white/15 shadow-2xl overflow-hidden z-10 animate-in zoom-in-95 duration-200">
        
        {/* Search Input Bar */}
        <div className="p-4 sm:p-6 border-b border-white/10 flex items-center gap-3">
          <Search className="w-5 h-5 text-blue-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search audio, chargers, earbuds, accessories..."
            className="w-full bg-transparent text-white placeholder-gray-400 focus:outline-none text-base sm:text-lg"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setIsSearchOpen(false)}
            className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-white/10"
            aria-label="Close search"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Tags */}
        <div className="px-6 py-3 bg-[#0B1630] border-b border-white/10 flex items-center gap-2 overflow-x-auto">
          <span className="text-xs text-[#8E9AB5] shrink-0">Popular:</span>
          {quickTags.map(tag => (
            <button
              key={tag}
              onClick={() => handleTagClick(tag)}
              className="text-xs px-2.5 py-1 rounded-lg bg-white/5 hover:bg-blue-600/30 text-[#B8C2D9] hover:text-white transition-colors shrink-0"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Search Results List */}
        <div className="p-4 sm:p-6 max-h-[380px] overflow-y-auto divide-y divide-white/5">
          <span className="text-xs uppercase tracking-wider font-bold text-[#8E9AB5] mb-3 block">
            {query.trim() === '' ? 'Recommended Gear' : `Results (${results.length})`}
          </span>

          {results.length === 0 ? (
            <div className="py-8 text-center text-gray-400">
              <p>No products found matching "{query}"</p>
              <button
                onClick={() => {
                  setIsSearchOpen(false);
                  setActivePage('shop');
                }}
                className="mt-3 text-xs text-blue-400 font-bold hover:underline"
              >
                Explore all items in store
              </button>
            </div>
          ) : (
            results.map(prod => (
              <div
                key={prod.id}
                className="py-3 flex items-center justify-between gap-4 group cursor-pointer hover:bg-white/5 px-2 rounded-xl transition-colors"
                onClick={() => handleProductSelect(prod)}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-12 h-12 bg-white rounded-xl p-1.5 shrink-0 flex items-center justify-center">
                    <img src={prod.image} alt={prod.name} className="max-h-full max-w-full object-contain" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[10px] uppercase font-bold text-blue-400 block">
                      {prod.category}
                    </span>
                    <h4 className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors truncate">
                      {prod.name}
                    </h4>
                    <div className="flex items-center gap-1 text-xs text-amber-400 mt-0.5">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>{prod.rating}</span>
                      <span className="text-[#8E9AB5]">({prod.reviewsCount})</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-sm font-extrabold text-white">
                    ${prod.price}.00
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(prod);
                      setIsSearchOpen(false);
                    }}
                    className="p-2 rounded-xl bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white transition-colors"
                    aria-label={`Add ${prod.name} to cart`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-[#0B1630] border-t border-white/10 text-center">
          <button
            onClick={() => {
              setIsSearchOpen(false);
              setActivePage('shop');
            }}
            className="text-xs font-bold text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
          >
            <span>View all products in shop</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
