import React from 'react';
import { useShop } from '../context/ShopContext';
import { ArrowRight, Flame, Clock } from 'lucide-react';

export const PromoBanner: React.FC = () => {
  const { setActivePage } = useShop();

  return (
    <section id="promo-banner-section" className="bg-[#F5F5FB] pb-14 sm:pb-20">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="relative rounded-3xl bg-gradient-to-br from-[#071126] via-[#0B1630] to-[#12224A] text-white p-8 sm:p-12 lg:p-14 overflow-hidden border border-white/10 shadow-2xl">
          
          {/* Ambient Lighting Orbs */}
          <div className="absolute -top-20 -left-20 w-80 h-80 bg-[#2563FF]/20 rounded-full blur-[90px] pointer-events-none" />
          <div className="absolute -bottom-20 right-20 w-80 h-80 bg-[#7C4DFF]/25 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute inset-0 bg-hero-grid opacity-25 pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            
            {/* Left Content */}
            <div className="lg:col-span-7 flex flex-col items-start">
              
              {/* Limited Time Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-500/20 border border-rose-500/30 text-rose-400 text-xs font-bold uppercase tracking-wider mb-5">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>Limited Time Promotion</span>
                <span className="w-1 h-1 rounded-full bg-rose-400" />
                <Clock className="w-3.5 h-3.5 text-rose-300" />
                <span className="normal-case font-medium">Ends in 48h</span>
              </div>

              {/* Headline */}
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight mb-4">
                Smarter Tech.{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2563FF] via-[#7C4DFF] to-[#A78BFA]">
                  Better Everyday.
                </span>
              </h2>

              {/* Supporting Text */}
              <p className="text-base sm:text-lg text-[#B8C2D9] max-w-lg mb-8 leading-relaxed">
                Save up to 30% on selected essentials this week. Upgrade your remote workstation, mobile audio, and high-speed charging arsenal.
              </p>

              {/* CTA Button */}
              <div className="flex flex-wrap items-center gap-4">
                <button
                  id="promo-shop-deals-btn"
                  onClick={() => setActivePage('deals')}
                  className="px-7 py-4 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] hover:shadow-lg hover:shadow-blue-500/30 active:scale-[0.98] transition-all duration-200 flex items-center gap-2 text-base group"
                >
                  <span>Shop the Deals</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </button>

                <span className="text-xs sm:text-sm text-[#8E9AB5]">
                  Use promo code <span className="font-mono font-bold text-white bg-white/10 px-2 py-1 rounded">MUDDASIR30</span> at checkout
                </span>
              </div>

            </div>

            {/* Right Product Composition Showcase */}
            <div className="lg:col-span-5 flex items-center justify-center relative">
              <div className="relative w-full max-w-sm flex items-center justify-center">
                
                {/* Luminous Center Backdrop */}
                <div className="w-64 h-64 rounded-full bg-gradient-to-tr from-blue-600/30 to-purple-600/30 blur-2xl absolute" />
                
                {/* Foreground Composite Tech Products */}
                <div className="relative z-10 grid grid-cols-2 gap-3 w-full">
                  <div className="bg-[#0B1630]/90 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 shadow-xl flex flex-col items-center">
                    <img
                      src="https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=400&q=80"
                      alt="PulsePods X2"
                      className="w-24 h-24 object-contain"
                    />
                    <span className="text-xs font-bold text-white mt-2">PulsePods X2</span>
                    <span className="text-[11px] font-semibold text-rose-400">Save 25%</span>
                  </div>

                  <div className="bg-[#0B1630]/90 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 shadow-xl flex flex-col items-center translate-y-4">
                    <img
                      src="https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=400&q=80"
                      alt="VoltCharge Pro"
                      className="w-24 h-24 object-contain"
                    />
                    <span className="text-xs font-bold text-white mt-2">VoltCharge Pro</span>
                    <span className="text-[11px] font-semibold text-rose-400">Save 24%</span>
                  </div>
                </div>

              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
