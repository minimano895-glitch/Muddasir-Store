import React from 'react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';
import { Star, Heart, ShoppingBag, Eye } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    addToCart,
    toggleWishlist,
    isWishlisted,
    setQuickViewProduct,
    setDetailProduct
  } = useShop();

  const wishlisted = isWishlisted(product.id);

  const badgeStyles: Record<string, string> = {
    'BEST SELLER': 'bg-[#2563FF] text-white',
    'TRENDING': 'bg-[#6D3DF5] text-white',
    'NEW ARRIVAL': 'bg-[#1D4ED8] text-white',
    'HOT DEAL': 'bg-rose-600 text-white',
    'LIMITED': 'bg-amber-600 text-white'
  };

  return (
    <div
      id={`product-card-${product.id}`}
      className="group relative bg-[#EEEEF8]/70 hover:bg-white rounded-2xl p-4 sm:p-5 border border-[#E4E5EE] hover:border-blue-200 transition-all duration-300 shadow-sm hover:shadow-xl hover:-translate-y-1 flex flex-col justify-between"
    >
      {/* Top Bar: Badge & Wishlist */}
      <div className="flex items-center justify-between gap-2 mb-3 relative z-10">
        {product.badge ? (
          <span className={`text-[10px] sm:text-[11px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-md shadow-sm ${badgeStyles[product.badge] || 'bg-blue-600 text-white'}`}>
            {product.badge}
          </span>
        ) : (
          <span />
        )}

        <div className="flex items-center gap-1.5">
          {/* Quick View Button */}
          <button
            onClick={e => {
              e.stopPropagation();
              setQuickViewProduct(product);
            }}
            className="w-8 h-8 rounded-full bg-white/90 hover:bg-white text-gray-600 hover:text-blue-600 flex items-center justify-center shadow-sm opacity-0 group-hover:opacity-100 transition-opacity duration-200 focus:opacity-100"
            aria-label={`Quick view ${product.name}`}
            title="Quick view"
          >
            <Eye className="w-4 h-4" />
          </button>

          {/* Wishlist Button */}
          <button
            onClick={e => {
              e.stopPropagation();
              toggleWishlist(product.id);
            }}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 shadow-sm ${
              wishlisted
                ? 'bg-rose-50 text-rose-500 border border-rose-200'
                : 'bg-white/90 hover:bg-white text-gray-500 hover:text-rose-500'
            }`}
            aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
            title="Wishlist"
          >
            <Heart className={`w-4 h-4 ${wishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Product Image Area */}
      <div
        className="w-full h-48 sm:h-56 relative flex items-center justify-center overflow-hidden rounded-xl bg-white p-4 cursor-pointer"
        onClick={() => setDetailProduct(product)}
      >
        <img
          src={product.image}
          alt={product.name}
          className="max-h-full max-w-full object-contain transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            // Fallback tech product image if network fails
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80';
          }}
        />
      </div>

      {/* Card Body */}
      <div className="mt-4 flex flex-col flex-grow justify-between">
        <div>
          {/* Category */}
          <span className="text-xs font-semibold uppercase tracking-wider text-[#687086]">
            {product.category}
          </span>

          {/* Product Name */}
          <h3
            onClick={() => setDetailProduct(product)}
            className="text-base sm:text-lg font-bold text-[#111827] hover:text-[#2563FF] transition-colors mt-0.5 line-clamp-1 cursor-pointer"
          >
            {product.name}
          </h3>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-1.5">
            <div className="flex items-center text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.floor(product.rating)
                      ? 'fill-amber-400 text-amber-400'
                      : 'fill-gray-200 text-gray-200'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs font-semibold text-gray-700">{product.rating}</span>
            <span className="text-xs text-[#687086]">({product.reviewsCount})</span>
          </div>
        </div>

        {/* Pricing & Add to Cart Circular Action (Directly inspired by reference) */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-[#E4E5EE]">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-2">
              <span className="text-lg sm:text-xl font-extrabold text-[#2563FF]">
                ${product.price}.00
              </span>
              {product.originalPrice && (
                <span className="text-xs sm:text-sm text-gray-400 line-through">
                  ${product.originalPrice}.00
                </span>
              )}
            </div>
            <span className="text-[11px] text-emerald-600 font-semibold">In Stock • Fast Shipping</span>
          </div>

          {/* Circular Add-to-Cart Button */}
          <button
            id={`add-to-cart-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product);
            }}
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#6D3DF5] hover:bg-[#5B2DE0] text-white flex items-center justify-center shadow-md shadow-purple-600/30 hover:scale-105 active:scale-95 transition-all duration-200 shrink-0"
            aria-label={`Add ${product.name} to cart`}
            title="Add to cart"
          >
            <ShoppingBag className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
