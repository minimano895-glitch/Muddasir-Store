import React from 'react';
import { Award, Truck, ShieldCheck, RefreshCw } from 'lucide-react';

export const TrustBar: React.FC = () => {
  const benefits = [
    {
      icon: <Award className="w-6 h-6 text-blue-400" />,
      title: 'Premium Quality',
      description: 'Carefully selected tech products'
    },
    {
      icon: <Truck className="w-6 h-6 text-blue-400" />,
      title: 'Fast Delivery',
      description: 'Quick shipping across the country'
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-blue-400" />,
      title: 'Secure Payments',
      description: 'Safe and reliable checkout'
    },
    {
      icon: <RefreshCw className="w-6 h-6 text-blue-400" />,
      title: 'Easy Returns',
      description: 'Simple 30-day return policy'
    }
  ];

  return (
    <section id="trust-bar" className="bg-[#0B1630] border-y border-white/10 py-6 sm:py-8">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-0 lg:divide-x lg:divide-white/10">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="flex items-center gap-4 px-2 sm:px-6 lg:justify-center group"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-900/30 border border-blue-500/20 flex items-center justify-center shrink-0 group-hover:bg-blue-600/20 group-hover:border-blue-400/40 transition-all duration-200">
                {benefit.icon}
              </div>
              <div className="flex flex-col">
                <span className="text-sm sm:text-base font-bold text-white tracking-tight">
                  {benefit.title}
                </span>
                <span className="text-xs sm:text-sm text-[#B8C2D9] font-normal leading-tight">
                  {benefit.description}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
