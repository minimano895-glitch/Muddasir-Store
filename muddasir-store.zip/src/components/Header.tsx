import React, { useState, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { Logo } from './Logo';
import { PageView } from '../types';
import { Search, ShoppingBag, Heart, Menu, X, ArrowRight } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    activePage,
    setActivePage,
    cartCount,
    setIsCartOpen,
    setIsSearchOpen,
    wishlist,
    setSelectedCategory
  } = useShop();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { label: string; page: PageView }[] = [
    { label: 'Home', page: 'home' },
    { label: 'Shop', page: 'shop' },
    { label: 'Categories', page: 'categories' },
    { label: 'Deals', page: 'deals' },
    { label: 'About', page: 'about' },
    { label: 'Contact', page: 'contact' }
  ];

  const handleNavClick = (page: PageView) => {
    setSelectedCategory(null);
    setActivePage(page);
    setMobileMenuOpen(false);
  };

  return (
    <header
      id="main-header"
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        isScrolled
          ? 'bg-[#050B1C]/90 backdrop-blur-xl border-b border-white/10 shadow-lg shadow-black/20 py-3'
          : 'bg-[#050B1C] border-b border-white/5 py-4'
      }`}
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div onClick={() => handleNavClick('home')}>
            <Logo size="md" />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map(item => {
              const isActive = activePage === item.page;
              return (
                <button
                  key={item.page}
                  id={`nav-${item.page}`}
                  onClick={() => handleNavClick(item.page)}
                  className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all duration-200 relative ${
                    isActive
                      ? 'text-white font-semibold'
                      : 'text-[#B8C2D9] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0.5 left-3.5 right-3.5 h-[2px] bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Search Trigger */}
            <button
              id="header-search-btn"
              onClick={() => setIsSearchOpen(true)}
              className="p-2.5 text-[#B8C2D9] hover:text-white hover:bg-white/10 rounded-xl transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Search tech products"
              title="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Link */}
            <button
              id="header-wishlist-btn"
              onClick={() => handleNavClick('shop')}
              className="relative p-2.5 text-[#B8C2D9] hover:text-white hover:bg-white/10 rounded-xl transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="View wishlist"
              title="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-pink-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              id="header-cart-btn"
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 text-[#B8C2D9] hover:text-white hover:bg-white/10 rounded-xl transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Open Shopping Cart"
              title="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-1.5 right-1.5 min-w-4 h-4 px-1 rounded-full bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] text-white text-[10px] font-bold flex items-center justify-center shadow-md shadow-blue-500/40">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Primary CTA Shop Now */}
            <button
              id="header-shop-now-btn"
              onClick={() => handleNavClick('shop')}
              className="hidden sm:inline-flex items-center gap-1.5 px-4.5 py-2.5 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-[#2563FF] via-[#5B3BF5] to-[#7C4DFF] hover:opacity-95 shadow-md shadow-blue-600/25 hover:shadow-blue-500/40 active:scale-[0.98] transition-all"
            >
              <span>Shop Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2.5 text-[#B8C2D9] hover:text-white hover:bg-white/10 rounded-xl transition-colors"
              aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div
            id="mobile-nav-panel"
            className="md:hidden pt-4 pb-6 border-t border-white/10 mt-3 flex flex-col gap-2 animate-in slide-in-from-top duration-200"
          >
            {navItems.map(item => {
              const isActive = activePage === item.page;
              return (
                <button
                  key={item.page}
                  onClick={() => handleNavClick(item.page)}
                  className={`flex items-center justify-between px-4 py-3 rounded-xl text-base font-medium transition-colors ${
                    isActive
                      ? 'bg-blue-600/20 text-white border border-blue-500/30'
                      : 'text-[#B8C2D9] hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <span>{item.label}</span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-blue-400" />}
                </button>
              );
            })}

            <div className="pt-3">
              <button
                onClick={() => handleNavClick('shop')}
                className="w-full py-3.5 rounded-xl font-semibold text-white bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25"
              >
                <span>Shop All Gear</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
