import React from 'react';
import { Logo } from './Logo';
import { useShop } from '../context/ShopContext';
import { PageView } from '../types';
import { ShieldCheck, Lock, CreditCard, Instagram, Facebook, Twitter, Phone, Mail, MapPin } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setActivePage, setSelectedCategory } = useShop();

  const handleNav = (page: PageView, category?: string) => {
    if (category) {
      setSelectedCategory(category);
    } else {
      setSelectedCategory(null);
    }
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="bg-[#050B1C] text-[#B8C2D9] border-t border-white/10 pt-16 pb-12">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 mb-12">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 flex flex-col items-start pr-0 lg:pr-8">
            <Logo showTagline size="lg" />
            <p className="text-sm text-[#8E9AB5] mt-4 leading-relaxed max-w-sm">
              Premium consumer electronics engineered for everyday resilience, uncompromising fidelity, and modern aesthetics.
            </p>
            
            <div className="mt-6 flex items-center gap-3">
              <a
                href="#social"
                className="w-9 h-9 rounded-xl bg-[#0B1630] border border-white/10 hover:border-blue-500/40 text-[#B8C2D9] hover:text-white flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="#social"
                className="w-9 h-9 rounded-xl bg-[#0B1630] border border-white/10 hover:border-blue-500/40 text-[#B8C2D9] hover:text-white flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="#social"
                className="w-9 h-9 rounded-xl bg-[#0B1630] border border-white/10 hover:border-blue-500/40 text-[#B8C2D9] hover:text-white flex items-center justify-center transition-colors"
                aria-label="X Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
            </div>

            {/* Quick Contact Line */}
            <div className="mt-6 flex flex-col gap-2 text-xs text-[#8E9AB5]">
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-400" />
                <span>hello@muddasirstore.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400" />
                <span>+1 (800) 555-0199</span>
              </div>
            </div>
          </div>

          {/* Shop Col */}
          <div className="flex flex-col gap-3">
            <span className="text-sm font-bold text-white uppercase tracking-wider">Shop</span>
            <button onClick={() => handleNav('shop')} className="text-sm hover:text-white transition-colors text-left">
              All Products
            </button>
            <button onClick={() => handleNav('shop')} className="text-sm hover:text-white transition-colors text-left">
              New Arrivals
            </button>
            <button onClick={() => handleNav('shop')} className="text-sm hover:text-white transition-colors text-left">
              Best Sellers
            </button>
            <button onClick={() => handleNav('deals')} className="text-sm hover:text-white transition-colors text-left text-rose-400 hover:text-rose-300">
              Weekly Deals & Sale
            </button>
          </div>

          {/* Categories Col */}
          <div className="flex flex-col gap-3">
            <span className="text-sm font-bold text-white uppercase tracking-wider">Categories</span>
            <button onClick={() => handleNav('shop', 'Audio')} className="text-sm hover:text-white transition-colors text-left">
              Audio & Headphones
            </button>
            <button onClick={() => handleNav('shop', 'Chargers')} className="text-sm hover:text-white transition-colors text-left">
              Charging & GaN
            </button>
            <button onClick={() => handleNav('shop', 'Accessories')} className="text-sm hover:text-white transition-colors text-left">
              Smart Accessories
            </button>
            <button onClick={() => handleNav('shop', 'Wearables')} className="text-sm hover:text-white transition-colors text-left">
              Wearables & Watches
            </button>
            <button onClick={() => handleNav('shop', 'Smart Tech')} className="text-sm hover:text-white transition-colors text-left">
              Smart Tech & Desk
            </button>
          </div>

          {/* Company & Support Col */}
          <div className="flex flex-col gap-3">
            <span className="text-sm font-bold text-white uppercase tracking-wider">Company & Help</span>
            <button onClick={() => handleNav('about')} className="text-sm hover:text-white transition-colors text-left">
              About Muddasir Store
            </button>
            <button onClick={() => handleNav('contact')} className="text-sm hover:text-white transition-colors text-left">
              Contact & Support
            </button>
            <button onClick={() => handleNav('contact')} className="text-sm hover:text-white transition-colors text-left">
              Shipping & Tracking
            </button>
            <button onClick={() => handleNav('contact')} className="text-sm hover:text-white transition-colors text-left">
              30-Day Returns Policy
            </button>
            <button onClick={() => handleNav('contact')} className="text-sm hover:text-white transition-colors text-left">
              Privacy & Warranty
            </button>
          </div>

        </div>

        {/* Security & Payment Badges Strip */}
        <div className="py-6 border-y border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs text-[#8E9AB5]">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-white">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>256-Bit SSL Encrypted Checkout</span>
            </div>
            <div className="flex items-center gap-2 text-white">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>Official 1-Year Manufacturer Warranty</span>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono text-[11px] text-gray-400">
            <span className="px-2 py-1 rounded bg-[#0B1630] border border-white/10">VISA</span>
            <span className="px-2 py-1 rounded bg-[#0B1630] border border-white/10">MasterCard</span>
            <span className="px-2 py-1 rounded bg-[#0B1630] border border-white/10">Apple Pay</span>
            <span className="px-2 py-1 rounded bg-[#0B1630] border border-white/10">PayPal</span>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8E9AB5]">
          <span>© 2026 Muddasir Store. All rights reserved. “Power Your Everyday.”</span>
          <div className="flex items-center gap-6">
            <button onClick={() => handleNav('contact')} className="hover:text-white transition-colors">
              Privacy Policy
            </button>
            <button onClick={() => handleNav('contact')} className="hover:text-white transition-colors">
              Terms of Service
            </button>
            <button onClick={() => handleNav('contact')} className="hover:text-white transition-colors">
              Cookie Preferences
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
