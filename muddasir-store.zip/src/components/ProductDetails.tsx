import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { PRODUCTS } from '../data/products';
import { ProductCard } from './ProductCard';
import { Star, ArrowLeft, ShoppingBag, ShieldCheck, Truck, RotateCcw, Check, Heart } from 'lucide-react';

export const ProductDetails: React.FC = () => {
  const {
    detailProduct,
    setDetailProduct,
    addToCart,
    isWishlisted,
    toggleWishlist,
    setIsCheckoutOpen
  } = useShop();

  if (!detailProduct) return null;

  const product = detailProduct;
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0]?.name || '');
  const [quantity, setQuantity] = useState(1);

  const wishlisted = isWishlisted(product.id);
  const currentImage = product.galleryImages[activeImageIdx] || product.image;

  const relatedProducts = PRODUCTS.filter(
    p => p.id !== product.id && (p.category === product.category || p.featured)
  ).slice(0, 4);

  const handleBuyNow = () => {
    addToCart(product, quantity, selectedColor);
    setIsCheckoutOpen(true);
  };

  return (
    <div id="product-detail-view" className="bg-[#F5F5FB] min-h-screen py-8 sm:py-12">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back Navigation Bar */}
        <div className="mb-6">
          <button
            onClick={() => setDetailProduct(null)}
            className="inline-flex items-center gap-2 text-sm font-bold text-[#2563FF] hover:text-[#1D4ED8] bg-white px-4 py-2 rounded-xl border border-[#E4E5EE] shadow-sm transition-all hover:-translate-x-0.5"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Store</span>
          </button>
        </div>

        {/* Main Product Two-Column Layout */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E4E5EE] shadow-sm mb-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
            
            {/* Left Column: Image Gallery */}
            <div className="lg:col-span-6 flex flex-col gap-4">
              <div className="w-full h-80 sm:h-96 md:h-[450px] bg-[#EEEEF8]/60 rounded-3xl p-8 flex items-center justify-center border border-[#E4E5EE] relative overflow-hidden">
                <img
                  src={currentImage}
                  alt={product.name}
                  className="max-h-full max-w-full object-contain transition-transform duration-500 hover:scale-105"
                />
                {product.badge && (
                  <span className="absolute top-4 left-4 text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-lg bg-blue-600 text-white shadow-md">
                    {product.badge}
                  </span>
                )}
              </div>

              {/* Gallery Thumbnails */}
              {product.galleryImages.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-1">
                  {product.galleryImages.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIdx(idx)}
                      className={`w-20 h-20 rounded-2xl bg-[#EEEEF8]/60 p-2 border transition-all shrink-0 flex items-center justify-center ${
                        activeImageIdx === idx
                          ? 'border-blue-600 ring-4 ring-blue-500/15'
                          : 'border-[#E4E5EE] hover:border-gray-400'
                      }`}
                    >
                      <img src={img} alt="thumbnail" className="max-h-full max-w-full object-contain" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Right Column: Product Metadata & Actions */}
            <div className="lg:col-span-6 flex flex-col">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold uppercase tracking-widest text-[#2563FF]">
                  {product.category}
                </span>

                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-2.5 rounded-xl border transition-colors ${
                    wishlisted
                      ? 'bg-rose-50 text-rose-500 border-rose-200'
                      : 'bg-gray-50 text-gray-500 hover:text-rose-500 border-gray-200'
                  }`}
                  aria-label="Wishlist"
                >
                  <Heart className={`w-5 h-5 ${wishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
                </button>
              </div>

              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#111827] mt-2 tracking-tight">
                {product.name}
              </h1>

              {/* Rating & Reviews */}
              <div className="flex items-center gap-3 mt-3">
                <div className="flex items-center text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating)
                          ? 'fill-amber-400 text-amber-400'
                          : 'fill-gray-200 text-gray-200'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-bold text-gray-800">{product.rating}</span>
                <span className="text-sm text-[#687086]">({product.reviewsCount} customer reviews)</span>
                <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
                  Verified In Stock
                </span>
              </div>

              {/* Pricing */}
              <div className="flex items-baseline gap-4 mt-5">
                <span className="text-3xl sm:text-4xl font-extrabold text-[#2563FF]">
                  ${product.price}.00
                </span>
                {product.originalPrice && (
                  <span className="text-lg text-gray-400 line-through">
                    ${product.originalPrice}.00
                  </span>
                )}
                {product.originalPrice && (
                  <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-lg">
                    Save ${product.originalPrice - product.price}.00 ({(100 - (product.price / product.originalPrice) * 100).toFixed(0)}% Off)
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-base text-[#4B5563] mt-5 leading-relaxed">
                {product.description}
              </p>

              {/* Color Selection */}
              {product.colors.length > 0 && (
                <div className="mt-6">
                  <span className="text-xs font-bold uppercase tracking-wider text-gray-700 block mb-2.5">
                    Select Color: <strong className="text-black normal-case font-bold">{selectedColor}</strong>
                  </span>
                  <div className="flex items-center gap-3">
                    {product.colors.map(color => (
                      <button
                        key={color.name}
                        onClick={() => setSelectedColor(color.name)}
                        className={`w-9 h-9 rounded-full border-2 transition-all flex items-center justify-center ${
                          selectedColor === color.name
                            ? 'border-blue-600 ring-4 ring-blue-500/20 scale-105'
                            : 'border-gray-200 hover:scale-105'
                        }`}
                        style={{ backgroundColor: color.hex }}
                        title={color.name}
                        aria-label={color.name}
                      >
                        {selectedColor === color.name && (
                          <Check className={`w-4 h-4 ${color.hex === '#F9FAFB' || color.hex === '#F3F4F6' ? 'text-black' : 'text-white'}`} />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity and Actions */}
              <div className="mt-8 flex flex-col sm:flex-row items-stretch gap-3">
                {/* Quantity */}
                <div className="flex items-center justify-between border border-[#E4E5EE] rounded-xl bg-gray-50 px-3 py-2 w-32 shrink-0">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-1 text-gray-500 hover:text-black font-bold text-base"
                  >
                    -
                  </button>
                  <span className="text-sm font-bold text-gray-800">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-1 text-gray-500 hover:text-black font-bold text-base"
                  >
                    +
                  </button>
                </div>

                {/* Add to Cart */}
                <button
                  id="detail-add-to-cart-btn"
                  onClick={() => addToCart(product, quantity, selectedColor)}
                  className="flex-1 py-3.5 px-6 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#6D3DF5] hover:opacity-95 shadow-md shadow-blue-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 text-sm"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Cart (${product.price * quantity}.00)</span>
                </button>

                {/* Buy Now */}
                <button
                  id="detail-buy-now-btn"
                  onClick={handleBuyNow}
                  className="py-3.5 px-6 rounded-xl font-bold text-gray-900 bg-[#EEEEF8] hover:bg-gray-200 border border-[#E4E5EE] transition-all text-sm shrink-0"
                >
                  Buy Now
                </button>
              </div>

              {/* Guarantees Box */}
              <div className="mt-8 p-5 bg-[#EEEEF8]/60 rounded-2xl border border-[#E4E5EE] grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-[#4B5563]">
                <div className="flex items-center gap-2.5">
                  <Truck className="w-5 h-5 text-blue-600 shrink-0" />
                  <div>
                    <strong className="block text-gray-900">Free Express Delivery</strong>
                    <span>Orders over $75 ship free</span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0" />
                  <div>
                    <strong className="block text-gray-900">1-Year Warranty</strong>
                    <span>Comprehensive coverage</span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <RotateCcw className="w-5 h-5 text-blue-600 shrink-0" />
                  <div>
                    <strong className="block text-gray-900">30-Day Returns</strong>
                    <span>Hassle-free guarantee</span>
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* Key Features & Specifications Table */}
          <div className="mt-12 pt-10 border-t border-[#E4E5EE] grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Features */}
            <div className="lg:col-span-7">
              <h3 className="text-xl font-bold text-[#111827] mb-4">
                Engineering Highlights
              </h3>
              <ul className="space-y-3">
                {product.features.map((feat, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-[#4B5563]">
                    <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Specifications */}
            <div className="lg:col-span-5">
              <h3 className="text-xl font-bold text-[#111827] mb-4">
                Technical Specifications
              </h3>
              <div className="bg-[#F5F5FB] rounded-2xl p-4 border border-[#E4E5EE] divide-y divide-[#E4E5EE]">
                {Object.entries(product.specs).map(([key, value]) => (
                  <div key={key} className="py-2.5 flex items-center justify-between text-xs sm:text-sm">
                    <span className="font-semibold text-gray-600">{key}</span>
                    <span className="font-bold text-gray-900">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Related Products Section */}
        {relatedProducts.length > 0 && (
          <div className="mt-14">
            <h2 className="text-2xl font-extrabold text-[#111827] mb-6">
              You Might Also Like
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {relatedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
