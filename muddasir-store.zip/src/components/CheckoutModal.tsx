import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, ShieldCheck, CheckCircle2, CreditCard, Truck, Lock, ArrowRight } from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    cartTotal,
    clearCart,
    setActivePage
  } = useShop();

  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmed'>('shipping');
  const [formData, setFormData] = useState({
    fullName: 'Alex Reynolds',
    email: 'alex.reynolds@example.com',
    address: '742 Evergreen Terrace',
    city: 'San Francisco',
    state: 'CA',
    postalCode: '94102',
    cardNumber: '•••• •••• •••• 4242',
    cardExpiry: '12/28',
    cardCvc: '883'
  });

  const [orderNumber, setOrderNumber] = useState('');

  if (!isCheckoutOpen) return null;

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedOrder = 'NG-' + Math.floor(100000 + Math.random() * 900000);
    setOrderNumber(generatedOrder);
    setStep('confirmed');
    clearCart();
  };

  const handleFinish = () => {
    setIsCheckoutOpen(false);
    setStep('shipping');
    setActivePage('home');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-md transition-opacity"
        onClick={() => step !== 'confirmed' && setIsCheckoutOpen(false)}
      />

      {/* Modal Container */}
      <div className="relative bg-[#071126] text-white rounded-3xl max-w-xl w-full border border-white/15 shadow-2xl overflow-hidden z-10 animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span className="text-base font-bold text-white">Muddasir Store Express Checkout</span>
          </div>
          {step !== 'confirmed' && (
            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="p-1.5 text-gray-400 hover:text-white rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Step Indicator */}
        {step !== 'confirmed' && (
          <div className="grid grid-cols-2 text-xs font-semibold border-b border-white/10 text-center">
            <div className={`py-3 flex items-center justify-center gap-2 ${step === 'shipping' ? 'bg-blue-600/20 text-blue-400 border-b-2 border-blue-500' : 'text-[#8E9AB5]'}`}>
              <Truck className="w-3.5 h-3.5" />
              <span>1. Shipping Address</span>
            </div>
            <div className={`py-3 flex items-center justify-center gap-2 ${step === 'payment' ? 'bg-blue-600/20 text-blue-400 border-b-2 border-blue-500' : 'text-[#8E9AB5]'}`}>
              <CreditCard className="w-3.5 h-3.5" />
              <span>2. Secure Payment</span>
            </div>
          </div>
        )}

        <div className="p-6 sm:p-8">
          {step === 'shipping' && (
            <form onSubmit={handleShippingSubmit} className="space-y-4">
              <h3 className="text-lg font-bold text-white mb-2">Shipping Information</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#B8C2D9] font-medium block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#B8C2D9] font-medium block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-[#B8C2D9] font-medium block mb-1">Street Address</label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-[#B8C2D9] font-medium block mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={e => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#B8C2D9] font-medium block mb-1">State</label>
                  <input
                    type="text"
                    required
                    value={formData.state}
                    onChange={e => setFormData({ ...formData, state: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#B8C2D9] font-medium block mb-1">Postal Code</label>
                  <input
                    type="text"
                    required
                    value={formData.postalCode}
                    onChange={e => setFormData({ ...formData, postalCode: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between border-t border-white/10">
                <span className="text-sm font-semibold text-[#B8C2D9]">Subtotal: ${cartTotal}.00</span>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] hover:opacity-95 text-sm flex items-center gap-2"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {step === 'payment' && (
            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              <h3 className="text-lg font-bold text-white mb-2">Payment Details</h3>
              
              <div className="p-4 rounded-2xl bg-[#0B1630] border border-blue-500/30 flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-blue-400" />
                  <span className="text-sm font-bold text-white">Credit / Debit Card</span>
                </div>
                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> 256-Bit SSL
                </span>
              </div>

              <div>
                <label className="text-xs text-[#B8C2D9] font-medium block mb-1">Card Number</label>
                <input
                  type="text"
                  required
                  value={formData.cardNumber}
                  onChange={e => setFormData({ ...formData, cardNumber: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#B8C2D9] font-medium block mb-1">Expiration</label>
                  <input
                    type="text"
                    required
                    value={formData.cardExpiry}
                    onChange={e => setFormData({ ...formData, cardExpiry: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#B8C2D9] font-medium block mb-1">Security Code (CVC)</label>
                  <input
                    type="text"
                    required
                    value={formData.cardCvc}
                    onChange={e => setFormData({ ...formData, cardCvc: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1630] border border-white/15 text-white text-sm font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setStep('shipping')}
                  className="text-xs text-[#B8C2D9] hover:text-white"
                >
                  ← Back to Shipping
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] hover:opacity-95 text-sm shadow-lg shadow-blue-500/25"
                >
                  Complete Order (${cartTotal}.00)
                </button>
              </div>
            </form>
          )}

          {step === 'confirmed' && (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <h3 className="text-2xl font-extrabold text-white">
                Thank You for Your Order!
              </h3>

              <p className="text-sm text-[#B8C2D9] max-w-sm mx-auto">
                Your order <strong className="text-white font-mono">{orderNumber}</strong> has been received and is being prepared for express dispatch.
              </p>

              <div className="p-4 rounded-2xl bg-[#0B1630] border border-white/10 text-left text-xs text-[#B8C2D9] space-y-2">
                <div className="flex justify-between">
                  <span>Confirmation sent to:</span>
                  <span className="font-semibold text-white">{formData.email}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping to:</span>
                  <span className="font-semibold text-white">{formData.address}, {formData.city}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Delivery:</span>
                  <span className="font-semibold text-emerald-400">2-3 Business Days</span>
                </div>
              </div>

              <button
                onClick={handleFinish}
                className="w-full py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] hover:opacity-95 shadow-md shadow-blue-500/20 text-sm mt-4"
              >
                Back to Muddasir Store
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
