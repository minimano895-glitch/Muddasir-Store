import React from 'react';
import { CATEGORIES } from '../data/categories';
import { useShop } from '../context/ShopContext';
import { ArrowRight } from 'lucide-react';

export const CategorySection: React.FC = () => {
  const { setActivePage, setSelectedCategory } = useShop();

  const handleCategoryClick = (categoryName: string) => {
    setSelectedCategory(categoryName);
    setActivePage('shop');
  };

  return (
    <section id="categories-section" className="bg-[#F5F5FB] pb-14 sm:pb-20">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-8 sm:mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-[#6D3DF5] mb-1.5 block">
            Explore Collections
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#111827] tracking-tight">
            Shop By Category
          </h2>
          <p className="text-sm sm:text-base text-[#687086] mt-1.5 max-w-xl">
            Engineered hardware tailored for high performance, mobile workflows, and home sanctuaries.
          </p>
        </div>

        {/* 6 Category Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.map(category => (
            <div
              key={category.id}
              id={`cat-card-${category.id}`}
              onClick={() => handleCategoryClick(category.name)}
              className="group relative bg-[#EEEEF8]/80 hover:bg-white rounded-3xl p-6 border border-[#E4E5EE] hover:border-blue-300 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between min-h-[260px]"
            >
              {/* Reference-inspired curved blue/purple ambient line wave in the background */}
              <div className="absolute right-0 bottom-0 w-48 h-48 pointer-events-none opacity-40 group-hover:opacity-75 transition-opacity">
                <svg viewBox="0 0 200 200" fill="none" className="w-full h-full text-blue-500/30">
                  <path
                    d="M20 180C60 140 80 170 140 120C170 95 180 40 200 10"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeDasharray="4 4"
                  />
                  <path
                    d="M10 190C70 150 100 160 160 110C185 90 195 50 205 20"
                    stroke="#7C4DFF"
                    strokeWidth="1.5"
                    strokeOpacity="0.4"
                  />
                  <path
                    d="M0 200C80 160 120 150 180 100C195 85 200 60 210 30"
                    stroke="#2563FF"
                    strokeWidth="1.5"
                    strokeOpacity="0.3"
                  />
                </svg>
              </div>

              {/* Text Information */}
              <div className="relative z-10 max-w-[65%]">
                <span className="text-[11px] font-bold tracking-wider uppercase text-blue-600 mb-1 block">
                  {category.itemCount} Products
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-[#111827] group-hover:text-blue-600 transition-colors">
                  {category.name}
                </h3>
                <p className="text-sm text-[#687086] mt-2 leading-relaxed">
                  {category.tagline}
                </p>
                <div className="inline-flex items-center gap-1.5 mt-5 text-sm font-bold text-blue-600 group-hover:text-blue-700 transition-colors">
                  <span>Shop Now</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>

              {/* Category Product Image (Integrated naturally in bottom right) */}
              <div className="absolute -bottom-2 -right-2 w-36 h-36 sm:w-40 sm:h-40 flex items-end justify-end pointer-events-none">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-32 h-32 sm:w-36 sm:h-36 object-cover rounded-2xl shadow-lg border border-white/80 group-hover:scale-108 group-hover:-translate-y-1.5 transition-transform duration-500"
                  loading="lazy"
                />
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
