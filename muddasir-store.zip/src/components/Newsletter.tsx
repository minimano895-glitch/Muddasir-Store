import React, { useState } from 'react';
import { Mail, CheckCircle2, ArrowRight } from 'lucide-react';

export const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }

    setError('');
    setIsSubmitted(true);
  };

  return (
    <section id="newsletter-section" className="bg-[#050B1C] py-16 sm:py-20 border-t border-white/10 relative overflow-hidden">
      {/* Background Lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-purple-600/15 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-[800px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-900/30 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider mb-4">
          <Mail className="w-3.5 h-3.5" />
          <span>Exclusive Community</span>
        </div>

        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-4">
          Stay Ahead of the{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2563FF] to-[#7C4DFF]">
            Tech
          </span>
        </h2>

        <p className="text-base sm:text-lg text-[#B8C2D9] max-w-lg mx-auto mb-8 leading-relaxed">
          Get new product alerts, exclusive offers, and smart tech recommendations delivered directly to your inbox.
        </p>

        {isSubmitted ? (
          <div className="bg-[#0B1630] border border-emerald-500/40 rounded-2xl p-6 max-w-md mx-auto flex items-center justify-center gap-3 text-emerald-400 animate-in fade-in zoom-in-95 duration-200">
            <CheckCircle2 className="w-6 h-6 shrink-0" />
            <div className="text-left">
              <span className="font-bold block text-white text-base">You're on the insider list!</span>
              <span className="text-xs text-emerald-300">Check your inbox for a 10% welcome coupon.</span>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="max-w-md mx-auto flex flex-col gap-2">
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-grow">
                <Mail className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="Enter your email address"
                  className="w-full pl-11 pr-4 py-3.5 rounded-xl bg-[#0B1630] border border-white/15 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm transition-all"
                />
              </div>

              <button
                type="submit"
                className="px-6 py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#6D3DF5] hover:opacity-95 shadow-md shadow-blue-600/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 text-sm shrink-0"
              >
                <span>Subscribe</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {error && (
              <span className="text-xs text-rose-400 font-medium text-left px-1 mt-1">
                {error}
              </span>
            )}

            <p className="text-xs text-[#8E9AB5] mt-2">
              No spam. Unsubscribe anytime.
            </p>
          </form>
        )}

      </div>
    </section>
  );
};
