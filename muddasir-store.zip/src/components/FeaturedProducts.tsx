import React, { useState } from 'react';
import { PRODUCTS } from '../data/products';
import { ProductCard } from './ProductCard';
import { useShop } from '../context/ShopContext';
import { ArrowRight } from 'lucide-react';

export const FeaturedProducts: React.FC = () => {
  const { setActivePage, setSelectedCategory } = useShop();
  const [activeFilter, setActiveFilter] = useState<string>('All');

  const filterTabs = ['All', 'Audio', 'Earbuds', 'Chargers', 'Accessories'];

  const filteredProducts = PRODUCTS.slice(0, 8).filter(product => {
    if (activeFilter === 'All') return true;
    if (activeFilter === 'Audio') return product.category === 'Audio' || product.category === 'Speakers';
    return product.category === activeFilter;
  });

  return (
    <section id="featured-products-section" className="bg-[#F5F5FB] py-14 sm:py-20">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 sm:mb-10">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#2563FF] mb-1.5 block">
              Curated Catalog
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#111827] tracking-tight">
              Featured Products
            </h2>
            <p className="text-sm sm:text-base text-[#687086] mt-1.5 max-w-xl">
              Top-rated tech essentials selected for performance, style, and everyday convenience.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Filter Pills */}
            <div className="hidden sm:flex items-center p-1 bg-[#EEEEF8] rounded-xl border border-[#E4E5EE]">
              {filterTabs.map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveFilter(tab)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150 ${
                    activeFilter === tab
                      ? 'bg-white text-[#2563FF] shadow-sm'
                      : 'text-[#687086] hover:text-[#111827]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <button
              id="view-all-products-btn"
              onClick={() => {
                setSelectedCategory(null);
                setActivePage('shop');
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-bold text-[#2563FF] hover:text-[#1D4ED8] bg-blue-50/80 hover:bg-blue-100 border border-blue-200/60 transition-colors shrink-0"
            >
              <span>View All Products</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Responsive Grid: 4 cols on desktop, 2-3 tablet, 1-2 mobile */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 sm:gap-6">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

      </div>
    </section>
  );
};
