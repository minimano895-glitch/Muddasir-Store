import React from 'react';

interface LogoProps {
  className?: string;
  showTagline?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: React.FC<LogoProps> = ({ className = '', showTagline = false, size = 'md' }) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-11 h-11'
  };

  const textSizes = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl'
  };

  return (
    <div className={`flex items-center gap-2.5 select-none cursor-pointer group ${className}`}>
      {/* Abstract Geometric 'M' Icon */}
      <div className={`relative ${iconSizes[size]} rounded-xl p-[2px] bg-gradient-to-br from-[#2563FF] via-[#5B3BF5] to-[#7C4DFF] shadow-lg shadow-blue-600/20 group-hover:shadow-blue-500/35 transition-all duration-300 flex items-center justify-center overflow-hidden`}>
        <div className="w-full h-full bg-[#071126] rounded-[10px] flex items-center justify-center relative">
          <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 transition-transform duration-300 group-hover:scale-105" xmlns="http://www.w3.org/2000/svg">
            {/* Geometric stylized M with precision tech angles */}
            <path
              d="M4 19V5H7.5L12 12L16.5 5H20V19H17V9.5L12.7 15.5H11.3L7 9.5V19H4Z"
              fill="url(#ms-gradient-inner)"
            />
            <defs>
              <linearGradient id="ms-gradient-inner" x1="4" y1="5" x2="20" y2="19" gradientUnits="userSpaceOnUse">
                <stop stopColor="#60A5FA" />
                <stop offset="0.4" stopColor="#2563FF" />
                <stop offset="1" stopColor="#7C4DFF" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity rounded-[10px]" />
        </div>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center gap-1.5">
          <span className={`font-extrabold tracking-tight text-white ${textSizes[size]}`}>
            Muddasir<span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] ml-1">Store</span>
          </span>
          <span className="text-[10px] font-bold tracking-widest uppercase px-1.5 py-0.5 rounded bg-blue-900/40 text-blue-400 border border-blue-500/20">
            OFFICIAL
          </span>
        </div>
        {showTagline && (
          <span className="text-[11px] font-medium text-[#B8C2D9] tracking-wide mt-0.5">
            Power Your Everyday.
          </span>
        )}
      </div>
    </div>
  );
};
