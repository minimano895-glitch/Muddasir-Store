import React from 'react';
import { Sparkles, Truck, ShieldCheck, Headphones } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const features = [
    {
      icon: <Sparkles className="w-6 h-6 text-white" />,
      gradient: 'from-[#2563FF] to-[#1D4ED8]',
      title: 'Premium Selection',
      description: 'Only products chosen for quality, performance, and everyday usefulness.'
    },
    {
      icon: <Truck className="w-6 h-6 text-white" />,
      gradient: 'from-[#6D3DF5] to-[#4F22C5]',
      title: 'Fast & Reliable Delivery',
      description: 'Get your order moving quickly with dependable real-time tracked shipping.'
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-white" />,
      gradient: 'from-[#2563FF] to-[#7C4DFF]',
      title: 'Secure Shopping',
      description: 'Your payments and personal data are safeguarded with 256-bit bank-grade encryption.'
    },
    {
      icon: <Headphones className="w-6 h-6 text-white" />,
      gradient: 'from-[#7C4DFF] to-[#A855F7]',
      title: 'Customer-First Support',
      description: 'Real tech specialists ready to help whenever you need answers or advice.'
    }
  ];

  return (
    <section id="why-choose-us-section" className="bg-[#050B1C] py-16 sm:py-24 relative overflow-hidden text-white">
      {/* Background Decorative Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-[#60A5FA] mb-2 block">
            The Muddasir Store Guarantee
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Why Shop With <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2563FF] to-[#7C4DFF]">Muddasir Store</span>?
          </h2>
          <p className="text-base text-[#B8C2D9] mt-3">
            We don't just sell electronics—we engineer an elevated customer journey from unboxing to daily productivity.
          </p>
        </div>

        {/* 4 Feature Columns with Circular Gradient Icons */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {features.map((feature, idx) => (
            <div
              key={idx}
              className="bg-[#0B1630]/90 backdrop-blur-sm rounded-3xl p-6 sm:p-7 border border-white/10 hover:border-blue-500/30 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-600/10 flex flex-col items-center text-center group"
            >
              {/* Large Circular Gradient Icon Background */}
              <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-5 shadow-lg shadow-blue-500/20 group-hover:scale-110 transition-transform duration-300`}>
                {feature.icon}
              </div>

              <h3 className="text-lg font-bold text-white mb-2.5">
                {feature.title}
              </h3>

              <p className="text-sm text-[#B8C2D9] leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
