import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, Star, ShoppingBag, Check, ShieldCheck, Truck, ArrowRight } from 'lucide-react';

export const QuickViewModal: React.FC = () => {
  const {
    quickViewProduct,
    setQuickViewProduct,
    addToCart,
    setDetailProduct
  } = useShop();

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState(1);

  if (!quickViewProduct) return null;

  const product = quickViewProduct;
  const activeColor = selectedColor || product.colors[0]?.name || '';
  const currentImage = product.galleryImages[selectedImageIndex] || product.image;

  const handleAddToCart = () => {
    addToCart(product, quantity, activeColor);
    setQuickViewProduct(null);
  };

  const handleViewFullDetails = () => {
    setDetailProduct(product);
    setQuickViewProduct(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        onClick={() => setQuickViewProduct(null)}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl z-10 border border-[#E4E5EE] animate-in zoom-in-95 duration-200">
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-5 right-5 p-2 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          
          {/* Product Gallery */}
          <div className="flex flex-col gap-4">
            <div className="w-full h-64 sm:h-72 bg-[#F5F5FB] rounded-2xl p-4 flex items-center justify-center border border-[#E4E5EE]">
              <img
                src={currentImage}
                alt={product.name}
                className="max-h-full max-w-full object-contain transition-all duration-300"
              />
            </div>

            {/* Thumbnail selector */}
            {product.galleryImages.length > 1 && (
              <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                {product.galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`w-16 h-16 rounded-xl bg-[#F5F5FB] p-1.5 border transition-all shrink-0 ${
                      selectedImageIndex === idx
                        ? 'border-[#2563FF] ring-2 ring-blue-500/20'
                        : 'border-[#E4E5EE] hover:border-gray-400'
                    }`}
                  >
                    <img src={img} alt="thumbnail" className="w-full h-full object-contain" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info & Controls */}
          <div className="flex flex-col">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2563FF]">
              {product.category}
            </span>

            <h2 className="text-2xl font-extrabold text-[#111827] mt-1">
              {product.name}
            </h2>

            {/* Rating */}
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating)
                        ? 'fill-amber-400 text-amber-400'
                        : 'fill-gray-200 text-gray-200'
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs font-bold text-gray-800">{product.rating}</span>
              <span className="text-xs text-[#687086]">({product.reviewsCount} reviews)</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mt-4">
              <span className="text-3xl font-extrabold text-[#2563FF]">
                ${product.price}.00
              </span>
              {product.originalPrice && (
                <span className="text-base text-gray-400 line-through">
                  ${product.originalPrice}.00
                </span>
              )}
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                In Stock
              </span>
            </div>

            {/* Description */}
            <p className="text-sm text-[#687086] mt-3 leading-relaxed">
              {product.description}
            </p>

            {/* Color Swatches */}
            {product.colors.length > 0 && (
              <div className="mt-4">
                <span className="text-xs font-semibold text-gray-700 block mb-2">
                  Color: <strong className="text-gray-900">{activeColor}</strong>
                </span>
                <div className="flex items-center gap-2.5">
                  {product.colors.map(col => (
                    <button
                      key={col.name}
                      onClick={() => setSelectedColor(col.name)}
                      className={`w-7 h-7 rounded-full border-2 transition-all flex items-center justify-center ${
                        activeColor === col.name
                          ? 'border-blue-600 ring-2 ring-blue-500/30 scale-110'
                          : 'border-transparent hover:scale-105'
                      }`}
                      style={{ backgroundColor: col.hex }}
                      title={col.name}
                      aria-label={col.name}
                    >
                      {activeColor === col.name && (
                        <Check className={`w-3.5 h-3.5 ${col.hex === '#F9FAFB' || col.hex === '#F3F4F6' ? 'text-black' : 'text-white'}`} />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity & Add to Cart */}
            <div className="flex items-center gap-3 mt-6">
              <div className="flex items-center border border-[#E4E5EE] rounded-xl bg-gray-50 px-2 py-1.5">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-2 text-gray-600 hover:text-black font-bold"
                >
                  -
                </button>
                <span className="px-3 text-sm font-bold text-gray-800">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-2 text-gray-600 hover:text-black font-bold"
                >
                  +
                </button>
              </div>

              <button
                id="modal-add-to-cart-btn"
                onClick={handleAddToCart}
                className="flex-1 py-3 px-5 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#6D3DF5] hover:opacity-95 shadow-md shadow-blue-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 text-sm"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Cart (${product.price * quantity}.00)</span>
              </button>
            </div>

            {/* Quick Guarantees */}
            <div className="grid grid-cols-2 gap-2 mt-5 pt-4 border-t border-[#E4E5EE] text-xs text-gray-500">
              <div className="flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-blue-500" />
                <span>Fast express delivery</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>1-year guarantee</span>
              </div>
            </div>

            <button
              onClick={handleViewFullDetails}
              className="mt-4 text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center justify-center gap-1"
            >
              <span>View Full Specs & Overview</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

          </div>

        </div>

      </div>
    </div>
  );
};
