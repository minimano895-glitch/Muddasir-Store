import React from 'react';
import { useShop } from '../context/ShopContext';
import { PRODUCTS } from '../data/products';
import { ArrowRight, Sparkles, ShieldCheck, Zap, Volume2, BatteryCharging } from 'lucide-react';

export const Hero: React.FC = () => {
  const { setActivePage, setDetailProduct, addToCart } = useShop();
  const heroProduct = PRODUCTS[0]; // AeroBeat Pro Headphones

  return (
    <section
      id="hero-section"
      className="relative overflow-hidden bg-[#050B1C] text-white pt-8 pb-16 lg:py-20"
    >
      {/* Background Ambient Glows & Grid Pattern */}
      <div className="absolute inset-0 bg-hero-grid pointer-events-none opacity-40" />
      <div className="absolute top-1/4 right-1/4 w-[450px] h-[450px] bg-[#2563FF]/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/6 w-[400px] h-[400px] bg-[#6D3DF5]/20 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center min-h-[580px] lg:min-h-[640px]">
          
          {/* Left Column - Typography & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-center lg:items-start text-center lg:text-left">
            {/* Eyebrow badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#0B1630] border border-blue-500/25 text-blue-400 text-xs font-semibold tracking-wider uppercase mb-6 shadow-sm shadow-blue-500/10">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>NEXT-GEN TECH • BUILT FOR EVERYDAY</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-[64px] font-extrabold tracking-tight leading-[1.04] text-white mb-6 max-w-2xl">
              Upgrade Your{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2563FF] via-[#7C4DFF] to-[#A78BFA]">
                Everyday Tech
              </span>
            </h1>

            {/* Supporting Copy */}
            <p className="text-base sm:text-lg text-[#B8C2D9] max-w-xl mb-8 leading-relaxed font-normal">
              Discover premium audio, smart accessories, and everyday tech essentials engineered for better performance, comfort, and style.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center gap-3.5 w-full sm:w-auto mb-8">
              <button
                id="hero-shop-cta"
                onClick={() => setActivePage('shop')}
                className="w-full sm:w-auto px-7 py-4 rounded-xl font-semibold text-white bg-gradient-to-r from-[#2563FF] via-[#5B3BF5] to-[#7C4DFF] hover:shadow-lg hover:shadow-blue-500/30 active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2.5 text-base group"
              >
                <span>Shop Collection</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                id="hero-explore-cta"
                onClick={() => {
                  setDetailProduct(heroProduct);
                }}
                className="w-full sm:w-auto px-6 py-4 rounded-xl font-semibold text-[#E2E8F0] hover:text-white bg-[#0B1630] hover:bg-[#12224A] border border-white/10 hover:border-white/20 transition-all duration-200 flex items-center justify-center gap-2 text-base"
              >
                <span>Explore AeroBeat Pro</span>
              </button>
            </div>

            {/* Small Trust Indicator */}
            <div className="flex items-center gap-3 text-xs sm:text-sm text-[#B8C2D9]/90 pt-2 border-t border-white/10 w-full sm:w-auto justify-center lg:justify-start">
              <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Free shipping on orders over $75</span>
              </div>
              <span className="text-white/20">•</span>
              <span className="text-[#8E9AB5]">30-day money-back guarantee</span>
            </div>
          </div>

          {/* Right Column - Hero Product Composition */}
          <div className="lg:col-span-5 flex items-center justify-center relative">
            
            {/* The circular glowing portal / neon rings backdrop inspired by reference */}
            <div className="relative w-full max-w-[420px] aspect-square flex items-center justify-center">
              
              {/* Outer Neon Ring */}
              <div className="absolute inset-4 rounded-full border border-blue-500/30 shadow-[0_0_60px_rgba(37,99,255,0.35)] animate-pulse" style={{ animationDuration: '4s' }} />
              
              {/* Inner Radiant Halo */}
              <div className="absolute inset-10 rounded-full border border-purple-500/40 shadow-[0_0_80px_rgba(124,77,255,0.4)]" />
              
              {/* Concentric Glow Core */}
              <div className="absolute inset-16 rounded-full bg-gradient-to-tr from-[#0B1630] via-[#122452] to-[#1E1B4B] shadow-inner border border-white/10" />

              {/* Pedestal Platform (Bottom) */}
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-72 h-14 bg-gradient-to-b from-[#162758] to-[#0A1226] rounded-[50%] border-t border-blue-400/40 shadow-2xl shadow-blue-900/60 z-10" />

              {/* Floating Tech Badges */}
              <div className="absolute top-6 -left-4 sm:-left-6 z-30 bg-[#071126]/90 backdrop-blur-md border border-blue-500/30 px-3.5 py-2 rounded-xl shadow-xl flex items-center gap-2 animate-bounce" style={{ animationDuration: '6s' }}>
                <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">Soundstage</span>
                  <span className="text-xs font-semibold text-white">Spatial 360° ANC</span>
                </div>
              </div>

              <div className="absolute bottom-16 -right-2 sm:-right-4 z-30 bg-[#071126]/90 backdrop-blur-md border border-purple-500/30 px-3.5 py-2 rounded-xl shadow-xl flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
                  <BatteryCharging className="w-4 h-4" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">Fast Charge</span>
                  <span className="text-xs font-semibold text-white">40h Endurance</span>
                </div>
              </div>

              {/* Main Product Image */}
              <div className="relative z-20 w-64 sm:w-72 md:w-80 group cursor-pointer" onClick={() => setDetailProduct(heroProduct)}>
                <img
                  src={heroProduct.image}
                  alt={heroProduct.name}
                  className="w-full h-auto object-contain drop-shadow-[0_25px_35px_rgba(0,0,0,0.85)] filter hover:scale-105 transition-transform duration-500 select-none"
                  loading="eager"
                />
              </div>

              {/* Subtle Ambient Floor Reflection */}
              <div className="absolute -bottom-6 w-56 h-12 bg-blue-500/20 rounded-full blur-xl pointer-events-none" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
