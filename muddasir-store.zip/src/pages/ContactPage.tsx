import React, { useState } from 'react';
import { Mail, Phone, Clock, MapPin, CheckCircle2, HelpCircle, ChevronDown } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      setError('Please fill in all required fields.');
      return;
    }
    setError('');
    setSubmitted(true);
  };

  const faqs = [
    {
      q: 'How long does shipping take for my Muddasir Store order?',
      a: 'Standard orders are dispatched within 24 business hours. Express domestic delivery arrives in 2–3 business days. Orders over $75 automatically receive complimentary express delivery.'
    },
    {
      q: 'What does the Muddasir Store 30-day return policy cover?',
      a: 'We want you to love your tech gear. If you are not completely satisfied, return the product in its original packaging within 30 calendar days for a full refund or exchange—no questions asked.'
    },
    {
      q: 'Are Muddasir Store chargers compatible with Apple, Android, and Windows devices?',
      a: 'Yes! All Muddasir Store chargers and hubs support universal Power Delivery (PD 3.0), Quick Charge (QC 4.0), and PPS adaptive voltage protocols, safely powering MacBooks, iPhones, Galaxy phones, and PC laptops.'
    },
    {
      q: 'How do I track my active shipment?',
      a: 'As soon as your package leaves our fulfillment warehouse, an email with your real-time tracking link and courier details will be sent directly to your registered email address.'
    }
  ];

  return (
    <div id="contact-page" className="bg-[#F5F5FB] min-h-screen py-12 sm:py-20">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-widest text-[#2563FF] mb-2 block">
            Customer Concierge
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#111827] tracking-tight">
            We’re Here to Help
          </h1>
          <p className="text-base text-[#687086] mt-2">
            Have a question about technical specs, warranty coverage, or your order? Reach our specialist team anytime.
          </p>
        </div>

        {/* Contact Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-14">
          <div className="bg-white rounded-3xl p-6 border border-[#E4E5EE] shadow-sm flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-gray-900">Email Us</h4>
              <p className="text-xs text-gray-500 mt-0.5">Average response under 2 hours</p>
              <a href="mailto:hello@muddasirstore.com" className="text-sm font-semibold text-blue-600 hover:underline block mt-2">
                hello@muddasirstore.com
              </a>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-[#E4E5EE] shadow-sm flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
              <Phone className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-gray-900">Call Toll-Free</h4>
              <p className="text-xs text-gray-500 mt-0.5">Mon–Sat, 9:00 AM–7:00 PM</p>
              <a href="tel:+18005550199" className="text-sm font-semibold text-purple-600 hover:underline block mt-2">
                +1 (800) 555-0199
              </a>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-[#E4E5EE] shadow-sm flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-gray-900">Hours & Support</h4>
              <p className="text-xs text-gray-500 mt-0.5">6 Days a week concierge</p>
              <span className="text-sm font-semibold text-gray-800 block mt-2">
                Mon–Sat: 9:00 AM – 7:00 PM EST
              </span>
            </div>
          </div>
        </div>

        {/* Contact Form & FAQ Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Contact Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-8 sm:p-10 border border-[#E4E5EE] shadow-sm">
            <h3 className="text-2xl font-extrabold text-[#111827] mb-2">
              Send a Direct Message
            </h3>
            <p className="text-sm text-[#687086] mb-6">
              Fill out the form below and our customer care team will get back to you promptly.
            </p>

            {submitted ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-8 text-center text-emerald-700 animate-in fade-in zoom-in-95 duration-200">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <h4 className="text-xl font-bold text-emerald-900">Message Received!</h4>
                <p className="text-sm text-emerald-800 mt-2 max-w-sm mx-auto">
                  Thank you, <strong>{form.name}</strong>. A support specialist will follow up at <strong>{form.email}</strong> shortly.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setForm({ name: '', email: '', subject: '', message: '' });
                  }}
                  className="mt-5 px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1.5">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Jordan Miller"
                      value={form.name}
                      onChange={e => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#F5F5FB] border border-[#E4E5EE] text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1.5">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. jordan@example.com"
                      value={form.email}
                      onChange={e => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#F5F5FB] border border-[#E4E5EE] text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-700 block mb-1.5">
                    Subject
                  </label>
                  <input
                    type="text"
                    placeholder="Product Inquiry, Order Tracking, Warranty..."
                    value={form.subject}
                    onChange={e => setForm({ ...form, subject: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#F5F5FB] border border-[#E4E5EE] text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-700 block mb-1.5">
                    Message *
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Describe how we can assist you..."
                    value={form.message}
                    onChange={e => setForm({ ...form, message: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#F5F5FB] border border-[#E4E5EE] text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {error && (
                  <span className="text-xs text-rose-500 font-semibold block">{error}</span>
                )}

                <button
                  type="submit"
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-[#2563FF] to-[#7C4DFF] hover:opacity-95 shadow-md shadow-blue-500/25 transition-all text-sm"
                >
                  Send Inquiry
                </button>
              </form>
            )}
          </div>

          {/* FAQ Accordion */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-8 border border-[#E4E5EE] shadow-sm">
            <div className="flex items-center gap-2 mb-6">
              <HelpCircle className="w-5 h-5 text-blue-600" />
              <h3 className="text-xl font-bold text-[#111827]">
                Frequently Asked Questions
              </h3>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, idx) => (
                <div
                  key={idx}
                  className="border border-[#E4E5EE] rounded-2xl overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                    className="w-full p-4 text-left font-bold text-sm text-gray-900 hover:text-blue-600 flex items-center justify-between gap-3"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-gray-400 shrink-0 transition-transform duration-200 ${
                        openFaq === idx ? 'rotate-180 text-blue-600' : ''
                      }`}
                    />
                  </button>
                  {openFaq === idx && (
                    <div className="px-4 pb-4 text-xs sm:text-sm text-gray-600 leading-relaxed bg-[#F5F5FB]/50 border-t border-[#E4E5EE] pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
