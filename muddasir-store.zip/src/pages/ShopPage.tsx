import React, { useState, useMemo } from 'react';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import { Search, SlidersHorizontal, ArrowUpDown, X, Star } from 'lucide-react';

export const ShopPage: React.FC = () => {
  const { selectedCategory, setSelectedCategory } = useShop();

  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>(selectedCategory || 'All');
  const [maxPrice, setMaxPrice] = useState<number>(200);
  const [minRating, setMinRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  // Sync if context category changed
  React.useEffect(() => {
    if (selectedCategory) {
      setActiveCategory(selectedCategory);
    }
  }, [selectedCategory]);

  const categories = ['All', 'Audio', 'Earbuds', 'Speakers', 'Chargers', 'Accessories', 'Smart Tech', 'Power', 'Wearables'];

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(product => {
      // Search
      if (search.trim()) {
        const query = search.toLowerCase();
        const matchName = product.name.toLowerCase().includes(query);
        const matchCat = product.category.toLowerCase().includes(query);
        const matchDesc = product.shortDescription.toLowerCase().includes(query);
        if (!matchName && !matchCat && !matchDesc) return false;
      }

      // Category
      if (activeCategory !== 'All') {
        if (activeCategory === 'Audio') {
          if (product.category !== 'Audio' && product.category !== 'Speakers' && product.category !== 'Earbuds') return false;
        } else if (activeCategory === 'Smart Accessories') {
          if (product.category !== 'Accessories' && product.category !== 'Smart Tech') return false;
        } else if (product.category !== activeCategory) {
          return false;
        }
      }

      // Price
      if (product.price > maxPrice) return false;

      // Rating
      if (product.rating < minRating) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [search, activeCategory, maxPrice, minRating, sortBy]);

  const resetFilters = () => {
    setSearch('');
    setActiveCategory('All');
    setSelectedCategory(null);
    setMaxPrice(200);
    setMinRating(0);
    setSortBy('featured');
  };

  const hasActiveFilters = search !== '' || activeCategory !== 'All' || maxPrice < 200 || minRating > 0;

  return (
    <div id="shop-page" className="bg-[#F5F5FB] min-h-screen py-10 sm:py-16">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Page Header */}
        <div className="mb-8">
          <span className="text-xs font-bold uppercase tracking-widest text-[#2563FF] mb-1.5 block">
            Muddasir Store Catalog
          </span>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-[#111827] tracking-tight">
                Shop All Products
              </h1>
              <p className="text-sm sm:text-base text-[#687086] mt-1">
                Showing {filteredProducts.length} high-performance essentials
              </p>
            </div>

            {/* Mobile Filter Trigger */}
            <button
              onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
              className="lg:hidden inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-[#E4E5EE] text-sm font-semibold text-gray-700 shadow-sm self-start"
            >
              <SlidersHorizontal className="w-4 h-4 text-blue-600" />
              <span>Filters {hasActiveFilters && '• Active'}</span>
            </button>
          </div>
        </div>

        {/* Top Controls Bar: Search & Sort */}
        <div className="bg-white rounded-2xl p-4 border border-[#E4E5EE] shadow-sm mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Search Box */}
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search gear by name, keyword..."
              className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-[#F5F5FB] border border-[#E4E5EE] focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Sort Dropdown & Reset */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-gray-500" />
              <span className="text-xs font-semibold text-gray-600">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="text-xs font-semibold bg-[#F5F5FB] border border-[#E4E5EE] rounded-xl px-3 py-2 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="featured">Featured Picks</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>

            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="text-xs font-bold text-rose-500 hover:text-rose-700 underline shrink-0"
              >
                Reset All
              </button>
            )}
          </div>
        </div>

        {/* Layout: Sidebar Filter + Product Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Sidebar Filter (Desktop + Mobile Toggle) */}
          <aside className={`lg:col-span-3 ${isMobileFilterOpen ? 'block' : 'hidden lg:block'} space-y-6`}>
            
            {/* Category Filter */}
            <div className="bg-white rounded-2xl p-5 border border-[#E4E5EE] shadow-sm">
              <h3 className="text-sm font-bold uppercase tracking-wider text-gray-900 mb-3">
                Categories
              </h3>
              <div className="space-y-1">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => {
                      setActiveCategory(cat);
                      setSelectedCategory(cat === 'All' ? null : cat);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center justify-between ${
                      activeCategory === cat
                        ? 'bg-[#2563FF] text-white font-semibold shadow-sm'
                        : 'text-gray-600 hover:bg-[#F5F5FB] hover:text-gray-900'
                    }`}
                  >
                    <span>{cat}</span>
                    {activeCategory === cat && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Filter Slider */}
            <div className="bg-white rounded-2xl p-5 border border-[#E4E5EE] shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-900">
                  Max Price
                </h3>
                <span className="text-sm font-extrabold text-[#2563FF]">${maxPrice}</span>
              </div>
              <input
                type="range"
                min="30"
                max="200"
                step="5"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#2563FF] cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-gray-400 mt-1 font-semibold">
                <span>$30</span>
                <span>$200+</span>
              </div>
            </div>

            {/* Rating Filter */}
            <div className="bg-white rounded-2xl p-5 border border-[#E4E5EE] shadow-sm">
              <h3 className="text-sm font-bold uppercase tracking-wider text-gray-900 mb-3">
                Minimum Rating
              </h3>
              <div className="space-y-1.5">
                {[
                  { label: 'All Ratings', value: 0 },
                  { label: '4.8 Stars & Up', value: 4.8 },
                  { label: '4.7 Stars & Up', value: 4.7 },
                  { label: '4.5 Stars & Up', value: 4.5 }
                ].map(r => (
                  <button
                    key={r.value}
                    onClick={() => setMinRating(r.value)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs sm:text-sm font-medium transition-colors flex items-center justify-between ${
                      minRating === r.value
                        ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      {r.value > 0 && <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />}
                      <span>{r.label}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

          </aside>

          {/* Product Grid Area */}
          <main className="lg:col-span-9">
            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-[#E4E5EE] shadow-sm">
                <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">No matching products found</h3>
                <p className="text-sm text-gray-500 max-w-md mx-auto mb-6">
                  Try adjusting your search criteria, price range, or category filter to discover our available gear.
                </p>
                <button
                  onClick={resetFilters}
                  className="px-6 py-2.5 rounded-xl font-semibold text-white bg-[#2563FF] hover:bg-[#1D4ED8] transition-colors text-sm"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </main>

        </div>

      </div>
    </div>
  );
};
